const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Church = sequelize.define("Church", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  district: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  pastor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
}, { timestamps: true });

module.exports = Church;
