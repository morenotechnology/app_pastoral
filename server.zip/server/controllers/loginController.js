const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Pastor = require("../models/Pastor");
const Leader = require("../models/Leader");

// Clave secreta para JWT (usa una variable de entorno en producción)
const JWT_SECRET = process.env.JWT_SECRET || "clave_secreta_super_segura";

// Controlador para el inicio de sesión
exports.login = async (req, res) => {
  const { email, password, role } = req.body;

  try {
    // Verificar el rol y buscar el usuario correspondiente
    let user;
    if (role === "pastor") {
      user = await Pastor.findOne({ where: { email } });
    } else if (role === "leader") {
      user = await Leader.findOne({ where: { email } });
    } else {
      return res.status(400).json({ message: "Rol inválido" });
    }

    // Verificar si el usuario existe
    if (!user) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    // Comparar la contraseña
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Contraseña incorrecta" });
    }

    // Generar token JWT
    const token = jwt.sign(
      { id: user.id, role },
      JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.status(200).json({
      message: "Inicio de sesión exitoso",
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role,
      },
    });
  } catch (error) {
    console.error("Error en el inicio de sesión:", error);
    res.status(500).json({ message: "Error del servidor" });
  }
};
