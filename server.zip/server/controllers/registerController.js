const Pastor = require("../models/Pastor");
const Leader = require("../models/Leader");
const Church = require("../models/Church");
const bcrypt = require("bcryptjs");

// Registrar pastor
exports.registerPastor = async (req, res) => {
  try {
    const { nombre_completo, correo, contraseña, iglesia, distrito } = req.body;
    const hashedPassword = await bcrypt.hash(contraseña, 10);

    const pastor = await Pastor.create({
      name: nombre_completo,
      email: correo,
      password: hashedPassword,
      district: distrito,
    });

    const church = await Church.create({
      name: iglesia,
      district: distrito,
      pastor_id: pastor.id,
    });

    res.status(201).json({ message: "Pastor registrado con éxito", pastor, church });
  } catch (error) {
    res.status(500).json({ message: "Error al registrar pastor", error });
  }
};

// Registrar líder
exports.registerLeader = async (req, res) => {
  try {
    const { nombre_completo, correo, contraseña, iglesia_id, comite } = req.body;
    const hashedPassword = await bcrypt.hash(contraseña, 10);

    const leader = await Leader.create({
      name: nombre_completo,
      email: correo,
      password: hashedPassword,
      church_id: iglesia_id,
      committee: comite,
    });

    res.status(201).json({ message: "Líder registrado con éxito", leader });
  } catch (error) {
    res.status(500).json({ message: "Error al registrar líder", error });
  }
};
console.log("Register controller alcanzado");
