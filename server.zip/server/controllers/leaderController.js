const bcrypt = require("bcryptjs");
const Leader = require("../models/Leader");
const Church = require("../models/Church");

exports.registerLeader = async (req, res) => {
  const { name, email, password, phone, church_id, committee } = req.body;

  try {
    // Validar que la iglesia exista
    const church = await Church.findByPk(church_id);
    if (!church) {
      return res.status(404).json({ message: "Iglesia no encontrada" });
    }

    // Verificar si el correo ya está registrado
    const existingLeader = await Leader.findOne({ where: { email } });
    if (existingLeader) {
      return res.status(409).json({ message: "El correo ya está registrado." });
    }

    // Encriptar la contraseña
    const hashedPassword = await bcrypt.hash(password, 10);

    // Crear el líder
    const newLeader = await Leader.create({
      name,
      email,
      password: hashedPassword,
      phone,
      church_id,
      committee,
    });

    res.status(201).json({ message: "Líder registrado con éxito.", leader: newLeader });
  } catch (error) {
    console.error("Error al registrar líder:", error);
    res.status(500).json({ message: "Error del servidor", error });
  }
};
