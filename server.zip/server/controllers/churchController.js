const Church = require("../models/Church");

// Obtener todas las iglesias
exports.getChurches = async (req, res) => {
  try {
    const churches = await Church.findAll();
    res.status(200).json(churches);
  } catch (error) {
    console.error("Error al obtener iglesias:", error);
    res.status(500).json({ message: "Error al obtener iglesias." });
  }
};
