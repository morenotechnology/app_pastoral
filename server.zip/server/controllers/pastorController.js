const bcrypt = require("bcryptjs");
const Pastor = require("../models/Pastor");
const Church = require("../models/Church");

exports.registerPastor = async (req, res) => {
  const { name, email, password, phone, church_name, church_location, years_of_ministry } = req.body;

  try {
    // Verificar si el correo ya está registrado
    const existingPastor = await Pastor.findOne({ where: { email } });
    if (existingPastor) {
      return res.status(409).json({ message: "El correo ya está registrado." });
    }

    // Encriptar la contraseña
    const hashedPassword = await bcrypt.hash(password, 10);

    // Crear la iglesia
    const church = await Church.create({
      name: church_name,
      location: church_location,
    });

    // Crear el pastor asociado a la iglesia
    const newPastor = await Pastor.create({
      name,
      email,
      password: hashedPassword,
      phone,
      church_id: church.id,
      years_of_ministry,
    });

    res.status(201).json({ message: "Pastor registrado con éxito.", pastor: newPastor });
  } catch (error) {
    console.error("Error al registrar pastor:", error);
    res.status(500).json({ message: "Error del servidor", error });
  }
};
