const express = require("express");
const cors = require("cors");
const sequelize = require("./config/database");

// Importar rutas
const pastorRoutes = require("./routes/pastorRoutes");
const leaderRoutes = require("./routes/leaderRoutes");
const authRoutes = require("./routes/authRoutes");
const registerRoutes = require("./routes/registerRoutes");
const churchRoutes = require("./routes/churchRoutes"); // Actualizado a "churchRoutes"
const loginRoutes = require("./routes/loginRoutes"); // Nuevo archivo
const app = express();

app.use(cors({
    origin: "http://localhost:3001", // Permitir solicitudes desde tu frontend
    methods: ["GET", "POST", "PUT", "DELETE"], // Métodos permitidos
    credentials: true, // Si estás usando cookies o headers personalizados
}));

app.use(express.json());

// Rutas
app.use("/api/pastors", pastorRoutes); // Rutas para pastores
app.use("/api/leaders", leaderRoutes); // Rutas para líderes
app.use("/api/auth", authRoutes); // Rutas de autenticación
app.use("/api/churches", churchRoutes); // Rutas para iglesias
app.use("/api/login", loginRoutes); // Rutas para login
app.use("/api/register", registerRoutes);
// Sincronizar base de datos
sequelize
  .sync({ alter: true })
  .then(() => {
    console.log("Base de datos sincronizada");
  })
  .catch((error) => {
    console.error("Error al sincronizar la base de datos:", error);
  });

// Puerto del servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`Servidor ejecutándose en: http://localhost:${PORT}`)
);
