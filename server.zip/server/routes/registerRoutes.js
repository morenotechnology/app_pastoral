const express = require("express");
const router = express.Router();
const registerController = require("../controllers/registerController");

// Ruta para registrar un pastor
router.post("/pastor", registerController.registerPastor);

// Ruta para registrar un líder
router.post("/leader", registerController.registerLeader);

module.exports = router;
