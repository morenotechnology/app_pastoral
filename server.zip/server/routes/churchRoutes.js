const express = require("express");
const { getChurches } = require("../controllers/churchController");

const router = express.Router();

// Ruta para obtener todas las iglesias
router.get("/", getChurches);

module.exports = router;
