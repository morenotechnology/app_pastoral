const express = require("express");
const router = express.Router();
const { registerPastor } = require("../controllers/registerController");

// Ruta para registrar un pastor
router.post("/register", registerPastor);

module.exports = router;
